import { Link, NavLink, useNavigate } from 'react-router-dom'
import clsx from 'clsx'
import { Button } from '../ui/Button'
import { useAuthStore } from '../../features/auth/authStore'

const mobileItems = [
  { to: '/profile', label: 'Profile' },
  { to: '/schedule', label: 'Schedule' },
  { to: '/settings', label: 'Settings' },
]

export function Topbar() {
  const navigate = useNavigate()
  const session = useAuthStore((state) => state.session)
  const clearSession = useAuthStore((state) => state.clearSession)

  function logout() {
    clearSession()
    navigate('/login', { replace: true })
  }

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200/70 bg-white/75 px-4 py-3 backdrop-blur-xl dark:border-slate-800 dark:bg-slate-950/75 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between gap-4">
        <Link to="/profile" className="lg:hidden">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-blue-600 font-black text-white">c</span>
        </Link>
        <div className="min-w-0">
          <p className="truncate text-sm font-bold text-slate-950 dark:text-white">{session?.doctor.fullName ?? 'Doctor'}</p>
          <p className="truncate text-xs text-slate-500 dark:text-slate-400">{session?.hospital.name ?? 'careOS Hospital'}</p>
        </div>
        <Button type="button" variant="ghost" onClick={logout}>
          Logout
        </Button>
      </div>

      <nav className="mt-3 grid grid-cols-3 gap-2 lg:hidden">
        {mobileItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              clsx(
                'rounded-2xl px-3 py-2 text-center text-xs font-bold transition',
                isActive
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 text-slate-600 dark:bg-slate-900 dark:text-slate-300',
              )
            }
          >
            {item.label}
          </NavLink>
        ))}
      </nav>
    </header>
  )
}
