import { NavLink } from 'react-router-dom'
import clsx from 'clsx'

const navItems = [
  { to: '/profile', label: 'Profile' },
  { to: '/profile/edit', label: 'Edit Profile' },
  { to: '/schedule', label: 'Schedule' },
  { to: '/settings', label: 'Settings' },
]

export function Sidebar() {
  return (
    <aside className="hidden w-72 shrink-0 border-r border-slate-200/70 bg-white/70 p-5 backdrop-blur-xl dark:border-slate-800 dark:bg-slate-950/70 lg:block">
      <div className="mb-8 flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-600 font-black text-white shadow-soft">c</div>
        <div>
          <p className="text-sm font-black uppercase tracking-[0.28em] text-blue-600">careOS</p>
          <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">Doctor Portal</p>
        </div>
      </div>

      <nav className="space-y-2">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              clsx(
                'flex rounded-2xl px-4 py-3 text-sm font-bold transition',
                isActive
                  ? 'bg-blue-600 text-white shadow-soft'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-950 dark:text-slate-300 dark:hover:bg-slate-900 dark:hover:text-white',
              )
            }
          >
            {item.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}
