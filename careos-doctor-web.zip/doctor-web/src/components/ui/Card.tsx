import type { HTMLAttributes, ReactNode } from 'react'
import clsx from 'clsx'

type CardProps = HTMLAttributes<HTMLDivElement> & {
  children: ReactNode
  glass?: boolean
}

export function Card({ children, className, glass = false, ...props }: CardProps) {
  return (
    <div
      className={clsx(
        'rounded-3xl border border-slate-200/80 bg-white p-5 shadow-soft dark:border-slate-800 dark:bg-slate-950',
        glass && 'glass-panel shadow-glass',
        className,
      )}
      {...props}
    >
      {children}
    </div>
  )
}
