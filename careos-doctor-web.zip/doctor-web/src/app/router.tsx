import { Navigate, createBrowserRouter } from 'react-router-dom'
import { DoctorShell } from '../components/layout/DoctorShell'
import { LoginPage } from '../features/auth/LoginPage'
import { ProtectedRoute } from '../features/auth/ProtectedRoute'
import { DoctorProfilePage } from '../features/profile/DoctorProfilePage'
import { EditDoctorProfilePage } from '../features/profile/EditDoctorProfilePage'
import { DoctorSchedulePage } from '../features/schedule/DoctorSchedulePage'
import { DoctorSettingsPage } from '../features/settings/DoctorSettingsPage'

export const router = createBrowserRouter([
  {
    path: '/login',
    element: <LoginPage />,
  },
  {
    path: '/',
    element: (
      <ProtectedRoute>
        <DoctorShell />
      </ProtectedRoute>
    ),
    children: [
      { index: true, element: <Navigate to="/profile" replace /> },
      { path: 'profile', element: <DoctorProfilePage /> },
      { path: 'profile/edit', element: <EditDoctorProfilePage /> },
      { path: 'schedule', element: <DoctorSchedulePage /> },
      { path: 'settings', element: <DoctorSettingsPage /> },
    ],
  },
  {
    path: '*',
    element: <Navigate to="/profile" replace />,
  },
])
