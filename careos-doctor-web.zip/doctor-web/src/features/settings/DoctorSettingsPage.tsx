import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { useAuthStore } from '../auth/authStore'

export function DoctorSettingsPage() {
  const navigate = useNavigate()
  const clearSession = useAuthStore((state) => state.clearSession)
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem('careos-doctor-theme') === 'dark')

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode)
    localStorage.setItem('careos-doctor-theme', darkMode ? 'dark' : 'light')
  }, [darkMode])

  function logout() {
    clearSession()
    navigate('/login', { replace: true })
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <p className="text-sm font-black uppercase tracking-[0.25em] text-blue-600">Settings</p>
        <h1 className="mt-2 text-3xl font-black tracking-tight text-slate-950 dark:text-white">Doctor settings</h1>
        <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">Manage local app preferences and session controls.</p>
      </div>

      <Card>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-lg font-black text-slate-950 dark:text-white">Appearance</h2>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">Enable a darker interface for low-light use.</p>
          </div>
          <Button type="button" variant="secondary" onClick={() => setDarkMode((value) => !value)}>
            {darkMode ? 'Use light mode' : 'Use dark mode'}
          </Button>
        </div>
      </Card>

      <Card className="border-rose-200 dark:border-rose-900">
        <h2 className="text-lg font-black text-slate-950 dark:text-white">Session</h2>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">Log out safely from this browser. Your token will be removed from local storage.</p>
        <Button type="button" variant="danger" className="mt-5" onClick={logout}>
          Logout
        </Button>
      </Card>
    </div>
  )
}
