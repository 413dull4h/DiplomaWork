export type RoleName =
  | 'PATIENT'
  | 'DOCTOR'
  | 'HOSPITAL_ADMIN'
  | 'HOSPITAL_STAFF'
  | 'PLATFORM_ADMIN'
  | 'SUPER_ADMIN'

export type UserStatus = 'ACTIVE' | 'PENDING' | 'SUSPENDED' | 'DELETED'
export type HospitalStatus = 'PENDING' | 'APPROVED' | 'SUSPENDED' | 'REJECTED'
export type AppointmentType = 'IN_PERSON' | 'TELECONSULT'
export type AvailabilityAppointmentType = 'IN_PERSON' | 'TELECONSULT' | 'BOTH'
export type DayOfWeek =
  | 'SUNDAY'
  | 'MONDAY'
  | 'TUESDAY'
  | 'WEDNESDAY'
  | 'THURSDAY'
  | 'FRIDAY'
  | 'SATURDAY'

export type DoctorUser = {
  id: string
  email: string
  phone?: string | null
  primaryRole: RoleName
  status: UserStatus
  lastLoginAt?: string | null
  createdAt?: string
}

export type Doctor = {
  id: string
  userId?: string | null
  fullName: string
  specialization?: string | null
  licenseNumber?: string | null
  yearsExperience?: number | null
  bio?: string | null
  consultationFee?: number | string | null
  languages?: string[] | string | null
  qualifications?: string[] | string | null
  createdAt?: string
  updatedAt?: string
  deletedAt?: string | null
  user?: DoctorUser | null
}

export type Hospital = {
  id: string
  name: string
  legalName?: string | null
  contactPhone?: string | null
  contactEmail?: string | null
  licenseNumber?: string | null
  status: HospitalStatus
  timeZone?: string | null
  createdAt?: string
  updatedAt?: string
  deletedAt?: string | null
}

export type Department = {
  id: string
  hospitalId: string
  name: string
  description?: string | null
  createdAt?: string
  updatedAt?: string
  deletedAt?: string | null
}

export type DoctorAvailability = {
  id: string
  hospitalDoctorId: string
  dayOfWeek: DayOfWeek
  startTime: string
  endTime: string
  appointmentType: AvailabilityAppointmentType
  slotDurationMinutes: number
  isActive: boolean
  createdAt?: string
  updatedAt?: string
  deletedAt?: string | null
}

export type HospitalDoctor = {
  id: string
  hospitalId: string
  doctorId: string
  departmentId?: string | null
  isActive: boolean
  doctor?: Doctor
  hospital?: Hospital
  department?: Department | null
  availabilities?: DoctorAvailability[]
  createdAt?: string
  updatedAt?: string
}

export type DoctorLoginResponse = {
  message: string
  token: string
  user: DoctorUser
  doctor: Doctor
  hospital: Hospital
  department?: Department | null
  hospitalDoctorId: string
}

export type DoctorMeResponse = {
  user: DoctorUser | null
  doctor: Doctor
  hospital: Hospital
  department?: Department | null
  hospitalDoctorId: string
}

export type DoctorProfileResponse = {
  hospitalDoctor: HospitalDoctor
  doctor: Doctor
  hospital: Hospital
  department?: Department | null
  availabilities: DoctorAvailability[]
}

export type UpdateDoctorProfilePayload = {
  fullName: string
  bio?: string
  yearsExperience?: number
  consultationFee?: number
}

export type UpdateDoctorProfileResponse = {
  message: string
  doctor: Doctor
}

export type AvailabilityResponse = {
  availabilities: DoctorAvailability[]
}

export type ApiErrorShape = {
  message: string
  status?: number
  errors?: unknown
}
