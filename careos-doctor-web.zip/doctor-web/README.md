# careOS Doctor Web

Hospital-scoped Doctor Profile frontend for careOS.

This app is intentionally limited to doctor authentication, doctor profile viewing/editing, hospital assignment display, schedule viewing, settings, and logout. It does not build marketplace doctor features, lab, pharmacy, or payment modules.

## Install

Extract this folder into:

```txt
apps/doctor-web
```

From the careOS project root:

```bash
pnpm install
pnpm --filter @careos/doctor-web dev
```

Doctor Web runs on:

```txt
http://localhost:5176
```

## Required environment file

Create:

```txt
apps/doctor-web/.env
```

Paste:

```env
VITE_HOSPITAL_API_URL=http://localhost:4002
```

## Test login

```txt
Email: doctor.ahmed@careos.com
Password: Doctor@12345
```

## Expected backend routes

```txt
POST /hospital/doctor-auth/login
GET  /hospital/doctor-auth/me
GET  /hospital/doctor/profile
PATCH /hospital/doctor/profile
GET  /hospital/doctor/availability
PATCH /hospital/doctor/availability/:id
```

## Backend notes

- `GET /hospital/doctor/profile` is used as the source of truth for doctor profile, hospital assignment, department assignment, and availability summary.
- `PATCH /hospital/doctor/profile` is used only for editable doctor fields.
- Phone, languages, and qualifications are shown only when returned by the backend. Editing those requires backend support. The current backend route may not support them yet.
- `GET /hospital/doctor/availability` may not exist in your current backend. The schedule page shows a clear missing-endpoint state instead of silently faking data.
- Raw JWT tokens are never shown in the UI.
