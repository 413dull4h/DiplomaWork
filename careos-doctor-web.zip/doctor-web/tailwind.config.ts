import type { Config } from 'tailwindcss'

export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      boxShadow: {
        glass: '0 24px 80px rgba(15, 23, 42, 0.14)',
        soft: '0 12px 40px rgba(15, 23, 42, 0.08)',
      },
      borderRadius: {
        '3xl': '1.75rem',
      },
      backgroundImage: {
        'doctor-glow': 'radial-gradient(circle at top left, rgba(59,130,246,0.24), transparent 32%), radial-gradient(circle at top right, rgba(14,165,233,0.18), transparent 28%), linear-gradient(135deg, rgba(255,255,255,0.88), rgba(248,250,252,0.64))',
      },
    },
  },
  plugins: [],
} satisfies Config
